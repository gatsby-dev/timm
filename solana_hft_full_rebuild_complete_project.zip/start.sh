#!/bin/bash
# Start the bot
export NODE_ENV=production
ts-node src/main.ts