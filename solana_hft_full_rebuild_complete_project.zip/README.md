# Solana HFT Bot
This is a high-frequency trading bot for Solana using various strategies and optimizations.